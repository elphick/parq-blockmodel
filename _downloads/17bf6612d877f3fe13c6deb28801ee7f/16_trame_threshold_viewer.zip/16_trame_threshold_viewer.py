"""Trame viewer example with two startup patterns.

This example shows both ways to start the same Trame app:

1. **File pattern**: point to a single ``.pbm`` file.
2. **Hive pattern**: point to a hive-style directory and use the in-app
   selector to drill down by levels and ``pbm.name``.

Use ``DEMO_SOURCE_KIND`` to switch between these patterns in one place.

This example is gallery-safe: it stays in Sphinx-Gallery, but skips runtime
app setup/launch while docs are being built.
"""

import logging
import tempfile
from pathlib import Path

import pyvista as pv

from parq_blockmodel import ParquetBlockModel
from parq_blockmodel.visualization import BlockModelTrameApp

logger = logging.getLogger(__name__)
logger.setLevel(logging.WARNING)

# sphinx_gallery_thumbnail_path = "../docs/_static/branding/parq-blockmodel-gallery-thumbnail.svg"
DEMO_SOURCE_KIND = "file"  # "file" or "hive"


def _seed_temporary_hive_demo() -> Path:
    hive_root = Path(tempfile.gettempdir()) / "parq_blockmodel_trame_hive_demo"
    asset_specs = [
        ("site=alpha", "scenario=base", "alpha_base_orebody.parquet", (4, 4, 4)),
        ("site=beta", "scenario=optimised", "beta_optimised_orebody.parquet", (4, 4, 4)),
    ]
    for site_level, scenario_level, filename, shape in asset_specs:
        parquet_path = hive_root / site_level / scenario_level / filename
        parquet_path.parent.mkdir(parents=True, exist_ok=True)
        ParquetBlockModel.create_toy_blockmodel(filename=parquet_path, shape=shape)
    return hive_root


def _resolve_source_path() -> Path:
    example_dir = Path(__file__).resolve().parent
    local_file = example_dir / "example_blocks_constructor.pbm"
    if DEMO_SOURCE_KIND == "hive":
        return _seed_temporary_hive_demo()

    return local_file

def main() -> None:
    source_path = _resolve_source_path()
    logger.warning("Launching Trame demo from %s", source_path)
    app_kwargs = {
        "app_name": "Demo App",
    }
    if source_path.is_dir():
        app_kwargs["data_filter_1_attribute"] = "depth"
        app_kwargs["data_filter_1_min"] = 1.25
        app_kwargs["scalar"] = "depth"
        app_kwargs["threshold_value"] = 2.1
        app = BlockModelTrameApp.from_hive_directory(source_path, **app_kwargs)
    else:
        app_kwargs["data_filter_1_attribute"] = "density"
        app_kwargs["data_filter_1_min"] = 2.4
        app_kwargs["scalar"] = "density"
        app_kwargs["threshold_value"] = 2.6
        app = BlockModelTrameApp.from_pbm_file(source_path, **app_kwargs)
    if getattr(pv, "BUILDING_GALLERY", False):
        logger.debug("Skipping live Trame launch while building the gallery.")
        return

    app.launch(port=8080, host="0.0.0.0")


if __name__ == "__main__" and not getattr(pv, "BUILDING_GALLERY", False):
    main()
